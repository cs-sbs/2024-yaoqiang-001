package com.bite.book.constant;

public class Constants {
    public static final String USER_SESSION_KEY = "user_session_key";
}
